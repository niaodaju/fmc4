import React, { useRef, useEffect,useState} from 'react';
import { fabric } from 'fabric';
import getImageSize from './image';
// export function FabricCanvas:React.FC<> = ()
interface Props {
  imgblob:Blob;
}
const  FabricCanvas: React.FC<Props> = ({imgblob}) => {
  const canvasRef=useRef(null)
  const [canvas,setCanvas] = useState<fabric.Canvas|null>(null)
  useEffect(()=>{
    getImageSize(imgblob).then((value)=>{
      console.log('value',value)
      const tempCanvas = new fabric.Canvas(canvasRef.current,{
        backgroundColor:'orange',
        width:value.width,
        height:value.height
      })
      const url = URL.createObjectURL(imgblob);
      console.log(url)
      fabric.Image.fromURL(url, function(oImg) {
        console.log('oimg',oImg)
        tempCanvas.add(oImg);
      });
      setCanvas(tempCanvas)
      })
    return ()=>{
      canvas && canvas.dispose()
    }
   },[canvasRef])

  return (<div>
    <canvas ref={canvasRef}></canvas>
  </div>)
}
export default FabricCanvas
// ({
//   setCanvas,
//   children,
// }: {
//   setCanvas: (canvas: fabric.Canvas) => void;
//   children?: React.ReactNode | React.ReactNodeArray;
// }) {
//   const canvasRef = useRef(null);

//   useEffect(() => {
//     setCanvas(
//       new fabric.Canvas(canvasRef.current, {
//         renderOnAddRemove: true,
//       }),
//     );
//   }, [setCanvas]);

//   return (
//     <>
//       <canvas ref={canvasRef}></canvas>
//       {children}
//     </>
//   );
// }

// (){

//   const canvas = useRef<fabric.Canvas>(null);

//   useEffect(() => {
//     canvas.current = initCanvas();

//     canvas.current.on("mouse:over", () => {
//       console.log('hello')
//     });
    
//     // destroy fabric on unmount
//     return () => {
//       canvas.current.dispose();
//       canvas.current = null;
//     };
//   }, []);

//   const initCanvas = () => (
//     new fabric.Canvas('canvas', {
//       height: 800,
//       width: 800,
//       backgroundColor: 'pink' ,
//       selection: false,
//       renderOnAddRemove: true,
//     })
//   );

//   return (
//     <div >
//       <canvas ref={canvas} />
//     </div>

//   )
//   }

