var fm={}
fm.imgPath = "@/resource/"
fm.HTTP="http://localhost:5000/api/"
export default fm
